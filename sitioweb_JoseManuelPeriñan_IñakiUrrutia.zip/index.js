function estableceOpacidad(cadena, valor){
	document.getElementById(cadena).style.opacity = valor;
}

function scrollBoton(){
	window.scrollTo(0, 5000);
}

